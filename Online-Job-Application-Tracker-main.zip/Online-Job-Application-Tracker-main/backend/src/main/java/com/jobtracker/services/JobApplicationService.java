package com.jobtracker.services;

import com.jobtracker.models.JobApplication;
import com.jobtracker.models.User;
import com.jobtracker.repositories.JobApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class JobApplicationService {
    
    @Autowired
    private JobApplicationRepository jobApplicationRepository;
    
    @Transactional(readOnly = true)
    public List<JobApplication> findAllByUser(User user) {
        return jobApplicationRepository.findByUser(user);
    }
    
    @Transactional(readOnly = true)
    public List<JobApplication> findByUserAndStatus(User user, JobApplication.ApplicationStatus status) {
        return jobApplicationRepository.findByUserAndStatus(user, status);
    }
    
    @Transactional(readOnly = true)
    public Optional<JobApplication> findById(Long id) {
        return jobApplicationRepository.findById(id);
    }
    
    @Transactional
    public JobApplication save(JobApplication jobApplication) {
        return jobApplicationRepository.save(jobApplication);
    }
    
    @Transactional
    public void deleteById(Long id) {
        jobApplicationRepository.deleteById(id);
    }
}
