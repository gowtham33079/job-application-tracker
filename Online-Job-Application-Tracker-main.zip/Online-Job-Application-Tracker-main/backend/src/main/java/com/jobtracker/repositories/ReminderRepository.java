package com.jobtracker.repositories;

import com.jobtracker.models.JobApplication;
import com.jobtracker.models.Reminder;
import com.jobtracker.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReminderRepository extends JpaRepository<Reminder, Long> {
    List<Reminder> findByJobApplication(JobApplication jobApplication);
    List<Reminder> findByJobApplicationUser(User user);
    List<Reminder> findByReminderDateBefore(LocalDateTime date);
    List<Reminder> findByCompletedFalseAndReminderDateBefore(LocalDateTime date);
}
