package com.jobtracker.services;

import com.jobtracker.models.JobApplication;
import com.jobtracker.models.Reminder;
import com.jobtracker.models.User;
import com.jobtracker.repositories.ReminderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ReminderService {
    
    @Autowired
    private ReminderRepository reminderRepository;
    
    public List<Reminder> findByJobApplication(JobApplication jobApplication) {
        return reminderRepository.findByJobApplication(jobApplication);
    }
    
    public List<Reminder> findByUser(User user) {
        return reminderRepository.findByJobApplicationUser(user);
    }
    
    public Optional<Reminder> findById(Long id) {
        return reminderRepository.findById(id);
    }
    
    public Reminder save(Reminder reminder) {
        return reminderRepository.save(reminder);
    }
    
    public void deleteById(Long id) {
        reminderRepository.deleteById(id);
    }
    
    // Scheduled task to process due reminders
    @Scheduled(cron = "0 0 8 * * ?") // Run at 8:00 AM every day
    public void processOverdueReminders() {
        LocalDateTime now = LocalDateTime.now();
        List<Reminder> overdueReminders = reminderRepository.findByCompletedFalseAndReminderDateBefore(now);
        
        // Process reminders - in a real app you could send emails or notifications here
        for (Reminder reminder : overdueReminders) {
            System.out.println("Overdue reminder: " + reminder.getTitle() + " for job at " + 
                               reminder.getJobApplication().getCompanyName());
        }
    }
}
