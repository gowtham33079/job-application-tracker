import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  Grid,
  CircularProgress
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { fetchJobs, deleteJob } from '../../slices/jobSlice';

const JobsList = () => {
  const dispatch = useDispatch();
  const { jobs, status, error } = useSelector(state => state.jobs);
  const [filter, setFilter] = useState('ALL');
  const [search, setSearch] = useState('');
  
  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchJobs());
    }
  }, [status, dispatch]);

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this job application?')) {
      dispatch(deleteJob(id));
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'APPLIED':
        return 'primary';
      case 'INTERVIEW_SCHEDULED':
        return 'warning';
      case 'INTERVIEW_COMPLETED':
        return 'info';
      case 'OFFER_RECEIVED':
        return 'success';
      case 'REJECTED':
        return 'error';
      case 'ACCEPTED':
        return 'success';
      case 'DECLINED':
        return 'error';
      default:
        return 'default';
    }
  };

  // Filter and search jobs
  const filteredJobs = jobs.filter(job => {
    const matchesFilter = filter === 'ALL' || job.status === filter;
    const matchesSearch = job.companyName.toLowerCase().includes(search.toLowerCase()) ||
                         job.jobTitle.toLowerCase().includes(search.toLowerCase()) ||
                         job.location.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  if (status === 'loading') {
    return (
      <Box display="flex" justifyContent="center" mt={10}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Job Applications
        </Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          component={RouterLink}
          to="/jobs/add"
        >
          Add New Job
        </Button>
      </Box>

      {error ? (
        <Paper sx={{ p: 3, mb: 4, bgcolor: 'error.light', color: 'error.contrastText' }}>
          <Typography variant="body1">Error loading your job applications: {error}</Typography>
        </Paper>
      ) : (
        <>
          <Paper sx={{ p: 2, mb: 4 }}>
            <Grid container spacing={2} alignItems="center">
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Search Jobs"
                  variant="outlined"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by company, title, or location"
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth variant="outlined">
                  <InputLabel id="status-filter-label">Status Filter</InputLabel>
                  <Select
                    labelId="status-filter-label"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                    label="Status Filter"
                  >
                    <MenuItem value="ALL">All Applications</MenuItem>
                    <MenuItem value="APPLIED">Applied</MenuItem>
                    <MenuItem value="INTERVIEW_SCHEDULED">Interview Scheduled</MenuItem>
                    <MenuItem value="INTERVIEW_COMPLETED">Interview Completed</MenuItem>
                    <MenuItem value="OFFER_RECEIVED">Offer Received</MenuItem>
                    <MenuItem value="ACCEPTED">Accepted</MenuItem>
                    <MenuItem value="REJECTED">Rejected</MenuItem>
                    <MenuItem value="DECLINED">Declined</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </Paper>

          {filteredJobs.length > 0 ? (
            <TableContainer component={Paper}>
              <Table sx={{ minWidth: 650 }}>
                <TableHead>
                  <TableRow>
                    <TableCell>Company</TableCell>
                    <TableCell>Position</TableCell>
                    <TableCell>Location</TableCell>
                    <TableCell>Applied Date</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredJobs.map((job) => (
                    <TableRow key={job.id}>
                      <TableCell component="th" scope="row">
                        <RouterLink to={`/jobs/${job.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                          {job.companyName}
                        </RouterLink>
                      </TableCell>
                      <TableCell>{job.jobTitle}</TableCell>
                      <TableCell>{job.location}</TableCell>
                      <TableCell>{new Date(job.applicationDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Chip 
                          label={job.status.replace('_', ' ')}
                          color={getStatusColor(job.status)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell align="center">
                        <IconButton
                          component={RouterLink}
                          to={`/jobs/edit/${job.id}`}
                          color="primary"
                          size="small"
                        >
                          <EditIcon />
                        </IconButton>
                        <IconButton
                          onClick={() => handleDelete(job.id)}
                          color="error"
                          size="small"
                        >
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Paper sx={{ p: 4, textAlign: 'center' }}>
              <Typography variant="body1" color="textSecondary">
                No job applications found. {search || filter !== 'ALL' ? 'Try adjusting your search or filter.' : 'Add your first job application!'}
              </Typography>
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                component={RouterLink}
                to="/jobs/add"
                sx={{ mt: 2 }}
              >
                Add New Job
              </Button>
            </Paper>
          )}
        </>
      )}
    </Container>
  );
};

export default JobsList;