import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link as RouterLink } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import {
  Container,
  Typography,
  Box,
  Paper,
  Grid,
  Button,
  Chip,
  Divider,
  Tab,
  Tabs,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import { fetchJobs, deleteJob } from '../../slices/jobSlice';

// Custom TabPanel component
function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

const JobDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const { jobs, status, error } = useSelector(state => state.jobs);
  const job = jobs.find(job => job.id === Number(id));
  
  const [tabValue, setTabValue] = useState(0);
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [reminderDialogOpen, setReminderDialogOpen] = useState(false);
  const [interviewDialogOpen, setInterviewDialogOpen] = useState(false);
  
  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchJobs());
    }
  }, [status, dispatch]);

  const handleDeleteJob = () => {
    if (window.confirm('Are you sure you want to delete this job application?')) {
      dispatch(deleteJob(Number(id)));
      navigate('/jobs');
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'APPLIED':
        return 'primary';
      case 'INTERVIEW_SCHEDULED':
        return 'warning';
      case 'INTERVIEW_COMPLETED':
        return 'info';
      case 'OFFER_RECEIVED':
        return 'success';
      case 'REJECTED':
        return 'error';
      case 'ACCEPTED':
        return 'success';
      case 'DECLINED':
        return 'error';
      default:
        return 'default';
    }
  };

  if (status === 'loading') {
    return (
      <Box display="flex" justifyContent="center" mt={10}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container>
        <Paper sx={{ p: 3, mt: 3, bgcolor: 'error.light', color: 'error.contrastText' }}>
          <Typography variant="h6">Error loading job application details</Typography>
          <Typography variant="body1">{error}</Typography>
          <Button 
            component={RouterLink} 
            to="/jobs" 
            variant="contained" 
            sx={{ mt: 2 }}
            startIcon={<ArrowBackIcon />}
          >
            Back to Jobs
          </Button>
        </Paper>
      </Container>
    );
  }

  if (!job) {
    return (
      <Container>
        <Paper sx={{ p: 3, mt: 3 }}>
          <Typography variant="h6">Job application not found</Typography>
          <Button 
            component={RouterLink} 
            to="/jobs" 
            variant="contained" 
            sx={{ mt: 2 }}
            startIcon={<ArrowBackIcon />}
          >
            Back to Jobs
          </Button>
        </Paper>
      </Container>
    );
  }

  // Placeholder - in a real app, you'd fetch notes, reminders and interviews from the backend
  const notes = job.notes || [];
  const reminders = job.reminders || [];
  const interviews = job.interviews || [];

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 3 }}>
        <Button 
          component={RouterLink} 
          to="/jobs" 
          startIcon={<ArrowBackIcon />}
          sx={{ mb: 2 }}
        >
          Back to Jobs
        </Button>
        
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
          <div>
            <Typography variant="h4" component="h1">
              {job.jobTitle}
            </Typography>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              {job.companyName} • {job.location}
            </Typography>
            <Chip 
              label={job.status.replace('_', ' ')} 
              color={getStatusColor(job.status)}
              sx={{ mb: 2 }}
            />
          </div>
          
          <Box>
            <Button
              component={RouterLink}
              to={`/jobs/edit/${job.id}`}
              variant="outlined"
              startIcon={<EditIcon />}
              sx={{ mr: 1 }}
            >
              Edit
            </Button>
            <Button
              variant="outlined"
              color="error"
              startIcon={<DeleteIcon />}
              onClick={handleDeleteJob}
            >
              Delete
            </Button>
          </Box>
        </Box>
      </Box>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" gutterBottom>Job Details</Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Typography variant="subtitle2" color="text.secondary">
              Application Date
            </Typography>
            <Typography variant="body1" paragraph>
              {job.applicationDate ? new Date(job.applicationDate).toLocaleDateString() : 'Not specified'}
            </Typography>
            
            {job.salary && (
              <>
                <Typography variant="subtitle2" color="text.secondary">
                  Salary
                </Typography>
                <Typography variant="body1" paragraph>
                  {job.salary}
                </Typography>
              </>
            )}
            
            <Typography variant="subtitle2" color="text.secondary">
              Job URL
            </Typography>
            <Typography variant="body1" paragraph>
              {job.jobUrl ? (
                <a href={job.jobUrl} target="_blank" rel="noopener noreferrer">
                  {job.jobUrl}
                </a>
              ) : 'Not specified'}
            </Typography>
            
            {job.followUpDate && (
              <>
                <Typography variant="subtitle2" color="text.secondary">
                  Follow-up Date
                </Typography>
                <Typography variant="body1" paragraph>
                  {new Date(job.followUpDate).toLocaleDateString()}
                </Typography>
              </>
            )}
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={8}>
          <Paper sx={{ width: '100%' }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs value={tabValue} onChange={handleTabChange} aria-label="job details tabs">
                <Tab label="Description" />
                <Tab label="Notes" />
                <Tab label="Reminders" />
                <Tab label="Interviews" />
              </Tabs>
            </Box>
            
            <TabPanel value={tabValue} index={0}>
              <Typography variant="h6" gutterBottom>Job Description</Typography>
              <Typography variant="body1" component="div" sx={{ whiteSpace: 'pre-line' }}>
                {job.jobDescription || 'No description available.'}
              </Typography>
            </TabPanel>
            
            <TabPanel value={tabValue} index={1}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Notes</Typography>
                <Button 
                  variant="contained" 
                  size="small" 
                  startIcon={<AddIcon />}
                  onClick={() => setNoteDialogOpen(true)}
                >
                  Add Note
                </Button>
              </Box>
              
              {notes.length > 0 ? (
                notes.map((note) => (
                  <Paper key={note.id} elevation={1} sx={{ p: 2, mb: 2 }}>
                    <Typography variant="subtitle1">{note.title}</Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                      {new Date(note.createdAt).toLocaleDateString()}
                    </Typography>
                    <Typography variant="body1">
                      {note.content}
                    </Typography>
                  </Paper>
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No notes added yet. Add a note to track important information about this application.
                </Typography>
              )}
            </TabPanel>
            
            <TabPanel value={tabValue} index={2}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Reminders</Typography>
                <Button 
                  variant="contained" 
                  size="small" 
                  startIcon={<AddIcon />}
                  onClick={() => setReminderDialogOpen(true)}
                >
                  Add Reminder
                </Button>
              </Box>
              
              {reminders.length > 0 ? (
                reminders.map((reminder) => (
                  <Paper key={reminder.id} elevation={1} sx={{ p: 2, mb: 2 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="subtitle1">{reminder.title}</Typography>
                      <Chip 
                        label={reminder.completed ? 'Completed' : 'Pending'} 
                        color={reminder.completed ? 'success' : 'warning'} 
                        size="small"
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                      Due: {new Date(reminder.reminderDate).toLocaleDateString()}
                    </Typography>
                    <Typography variant="body1">
                      {reminder.description}
                    </Typography>
                  </Paper>
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No reminders set yet. Add a reminder to help you follow up on this application.
                </Typography>
              )}
            </TabPanel>
            
            <TabPanel value={tabValue} index={3}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Interviews</Typography>
                <Button 
                  variant="contained" 
                  size="small" 
                  startIcon={<AddIcon />}
                  onClick={() => setInterviewDialogOpen(true)}
                >
                  Add Interview
                </Button>
              </Box>
              
              {interviews.length > 0 ? (
                interviews.map((interview) => (
                  <Paper key={interview.id} elevation={1} sx={{ p: 2, mb: 2 }}>
                    <Typography variant="subtitle1">
                      {interview.interviewType} Interview
                      {interview.interviewerName && ` with ${interview.interviewerName}`}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                      {new Date(interview.interviewDate).toLocaleString()}
                    </Typography>
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      <strong>Location:</strong> {interview.location || 'Not specified'}
                    </Typography>
                    {interview.notes && (
                      <Typography variant="body1">
                        <strong>Notes:</strong> {interview.notes}
                      </Typography>
                    )}
                  </Paper>
                ))
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No interviews scheduled yet. Add an interview when it's scheduled.
                </Typography>
              )}
            </TabPanel>
          </Paper>
        </Grid>
      </Grid>
      
      {/* Note Dialog - Simplified for this example */}
      <Dialog open={noteDialogOpen} onClose={() => setNoteDialogOpen(false)}>
        <DialogTitle>Add Note</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Title"
            fullWidth
            variant="outlined"
          />
          <TextField
            margin="dense"
            label="Content"
            fullWidth
            multiline
            rows={4}
            variant="outlined"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setNoteDialogOpen(false)}>Cancel</Button>
          <Button onClick={() => setNoteDialogOpen(false)} variant="contained">Add</Button>
        </DialogActions>
      </Dialog>
      
      {/* Simplified Reminder Dialog */}
      <Dialog open={reminderDialogOpen} onClose={() => setReminderDialogOpen(false)}>
        <DialogTitle>Add Reminder</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Title"
            fullWidth
            variant="outlined"
          />
          <TextField
            margin="dense"
            label="Description"
            fullWidth
            multiline
            rows={2}
            variant="outlined"
          />
          <TextField
            margin="dense"
            label="Due Date"
            type="date"
            fullWidth
            variant="outlined"
            InputLabelProps={{ shrink: true }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setReminderDialogOpen(false)}>Cancel</Button>
          <Button onClick={() => setReminderDialogOpen(false)} variant="contained">Add</Button>
        </DialogActions>
      </Dialog>
      
      {/* Simplified Interview Dialog */}
      <Dialog open={interviewDialogOpen} onClose={() => setInterviewDialogOpen(false)}>
        <DialogTitle>Add Interview</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Interview Type"
            placeholder="Phone, Video, On-site, etc."
            fullWidth
            variant="outlined"
          />
          <TextField
            margin="dense"
            label="Interviewer Name"
            fullWidth
            variant="outlined"
          />
          <TextField
            margin="dense"
            label="Date & Time"
            type="datetime-local"
            fullWidth
            variant="outlined"
            InputLabelProps={{ shrink: true }}
          />
          <TextField
            margin="dense"
            label="Location"
            placeholder="Address or online meeting link"
            fullWidth
            variant="outlined"
          />
          <TextField
            margin="dense"
            label="Notes"
            fullWidth
            multiline
            rows={2}
            variant="outlined"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setInterviewDialogOpen(false)}>Cancel</Button>
          <Button onClick={() => setInterviewDialogOpen(false)} variant="contained">Add</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default JobDetail;