import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams, Link as RouterLink } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import {
  Container,
  Typography,
  Box,
  Paper,
  TextField,
  Button,
  Grid,
  MenuItem,
  FormControl,
  InputLabel,
  Select,
  CircularProgress,
  Alert
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { fetchJobs, updateJob } from '../../slices/jobSlice';

const EditJob = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  const { jobs, status, error } = useSelector(state => state.jobs);
  const job = jobs.find(job => job.id === Number(id));
  
  const [loading, setLoading] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState(false);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchJobs());
    }
  }, [status, dispatch]);

  const validationSchema = Yup.object({
    companyName: Yup.string().required('Company name is required'),
    jobTitle: Yup.string().required('Job title is required'),
    location: Yup.string().required('Location is required'),
    status: Yup.string().required('Status is required'),
    applicationDate: Yup.date().required('Application date is required'),
  });

  const formik = useFormik({
    initialValues: {
      companyName: job?.companyName || '',
      jobTitle: job?.jobTitle || '',
      jobDescription: job?.jobDescription || '',
      location: job?.location || '',
      jobUrl: job?.jobUrl || '',
      salary: job?.salary || '',
      status: job?.status || 'APPLIED',
      applicationDate: job?.applicationDate ? new Date(job.applicationDate).toISOString().split('T')[0] : '',
      followUpDate: job?.followUpDate ? new Date(job.followUpDate).toISOString().split('T')[0] : '',
    },
    enableReinitialize: true,
    validationSchema,
    onSubmit: (values) => {
      setLoading(true);
      dispatch(updateJob({ id: Number(id), jobData: values }))
        .unwrap()
        .then(() => {
          setLoading(false);
          setUpdateSuccess(true);
          setTimeout(() => {
            navigate(`/jobs/${id}`);
          }, 1500);
        })
        .catch(() => {
          setLoading(false);
        });
    },
  });

  if (status === 'loading') {
    return (
      <Box display="flex" justifyContent="center" mt={10}>
        <CircularProgress />
      </Box>
    );
  }

  if (!job) {
    return (
      <Container>
        <Paper sx={{ p: 3, mt: 3 }}>
          <Typography variant="h6">Job application not found</Typography>
          <Button 
            component={RouterLink} 
            to="/jobs" 
            variant="contained" 
            sx={{ mt: 2 }}
            startIcon={<ArrowBackIcon />}
          >
            Back to Jobs
          </Button>
        </Paper>
      </Container>
    );
  }

  return (
    <Container maxWidth="md">
      <Box sx={{ mb: 3 }}>
        <Button 
          component={RouterLink} 
          to={`/jobs/${id}`}
          startIcon={<ArrowBackIcon />}
          sx={{ mb: 2 }}
        >
          Back to Job Details
        </Button>
        <Typography variant="h4" component="h1">
          Edit Job Application
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {updateSuccess && (
        <Alert severity="success" sx={{ mb: 3 }}>
          Job application updated successfully! Redirecting...
        </Alert>
      )}

      <Paper sx={{ p: 3 }}>
        <Box component="form" onSubmit={formik.handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                id="companyName"
                name="companyName"
                label="Company Name *"
                value={formik.values.companyName}
                onChange={formik.handleChange}
                error={formik.touched.companyName && Boolean(formik.errors.companyName)}
                helperText={formik.touched.companyName && formik.errors.companyName}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                id="jobTitle"
                name="jobTitle"
                label="Job Title *"
                value={formik.values.jobTitle}
                onChange={formik.handleChange}
                error={formik.touched.jobTitle && Boolean(formik.errors.jobTitle)}
                helperText={formik.touched.jobTitle && formik.errors.jobTitle}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                id="location"
                name="location"
                label="Location *"
                placeholder="City, State or Remote"
                value={formik.values.location}
                onChange={formik.handleChange}
                error={formik.touched.location && Boolean(formik.errors.location)}
                helperText={formik.touched.location && formik.errors.location}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                id="salary"
                name="salary"
                label="Salary"
                placeholder="e.g. $80,000 - $100,000"
                value={formik.values.salary}
                onChange={formik.handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="jobUrl"
                name="jobUrl"
                label="Job Posting URL"
                placeholder="https://..."
                value={formik.values.jobUrl}
                onChange={formik.handleChange}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                id="applicationDate"
                name="applicationDate"
                label="Application Date *"
                type="date"
                value={formik.values.applicationDate}
                onChange={formik.handleChange}
                error={formik.touched.applicationDate && Boolean(formik.errors.applicationDate)}
                helperText={formik.touched.applicationDate && formik.errors.applicationDate}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                id="followUpDate"
                name="followUpDate"
                label="Follow-up Date"
                type="date"
                value={formik.values.followUpDate}
                onChange={formik.handleChange}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel id="status-label">Status *</InputLabel>
                <Select
                  labelId="status-label"
                  id="status"
                  name="status"
                  value={formik.values.status}
                  onChange={formik.handleChange}
                  label="Status *"
                >
                  <MenuItem value="APPLIED">Applied</MenuItem>
                  <MenuItem value="INTERVIEW_SCHEDULED">Interview Scheduled</MenuItem>
                  <MenuItem value="INTERVIEW_COMPLETED">Interview Completed</MenuItem>
                  <MenuItem value="OFFER_RECEIVED">Offer Received</MenuItem>
                  <MenuItem value="ACCEPTED">Accepted</MenuItem>
                  <MenuItem value="REJECTED">Rejected</MenuItem>
                  <MenuItem value="DECLINED">Declined</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                id="jobDescription"
                name="jobDescription"
                label="Job Description"
                multiline
                rows={6}
                value={formik.values.jobDescription}
                onChange={formik.handleChange}
              />
            </Grid>
            <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
              <Button
                component={RouterLink}
                to={`/jobs/${id}`}
                variant="outlined"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                variant="contained"
                disabled={loading}
              >
                {loading ? 'Saving...' : 'Update Job Application'}
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
    </Container>
  );
};

export default EditJob;