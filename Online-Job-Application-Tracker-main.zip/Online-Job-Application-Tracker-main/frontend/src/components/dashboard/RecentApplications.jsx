import React from 'react';
import { 
  List, 
  ListItem, 
  ListItemText, 
  ListItemAvatar, 
  ListItemSecondaryAction,
  Avatar, 
  Divider, 
  Box,
  Typography,
  Chip,
  alpha
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { BusinessCenter } from '@mui/icons-material';

/**
 * Component to display recent job applications on the dashboard
 * @param {Object} props Component props
 * @param {Array} props.applications Array of job applications to display
 */
const RecentApplications = ({ applications = [] }) => {
  
  // Format the status string to be more readable
  const formatStatus = (status) => {
    if (!status) return '';
    return status.replace('_', ' ').replace(/\b\w/g, (l) => l.toUpperCase());
  };
  
  // Get appropriate color for status chip
  const getStatusColor = (status) => {
    switch (status) {
      case 'APPLIED':
        return 'primary';
      case 'INTERVIEW_SCHEDULED':
        return 'warning';
      case 'INTERVIEW_COMPLETED':
        return 'info';
      case 'OFFER_RECEIVED':
        return 'success';
      case 'ACCEPTED':
        return 'success';
      case 'REJECTED':
        return 'error';
      case 'DECLINED':
        return 'error';
      default:
        return 'default';
    }
  };
  
  // If no applications, show a message
  if (!applications || applications.length === 0) {
    return (
      <Box sx={{ py: 2, textAlign: 'center' }}>
        <Typography variant="body2" color="text.secondary">
          No recent applications found
        </Typography>
      </Box>
    );
  }

  return (
    <List disablePadding>
      {applications.map((job, index) => (
        <React.Fragment key={job.id}>
          <ListItem 
            button 
            component={RouterLink}
            to={`/jobs/${job.id}`}
            alignItems="flex-start"
            sx={{ 
              py: 2,
              px: 1,
              borderRadius: 1,
              '&:hover': {
                backgroundColor: theme => alpha(theme.palette.primary.main, 0.08),
              },
            }}
          >
            <ListItemAvatar>
              <Avatar 
                sx={{ 
                  bgcolor: 'primary.light', 
                  mr: 2,
                  width: 40,
                  height: 40
                }}
              >
                {job.companyName ? job.companyName.charAt(0).toUpperCase() : <BusinessCenter />}
              </Avatar>
            </ListItemAvatar>
            <ListItemText
              primary={
                <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                  {job.jobTitle}
                </Typography>
              }
              secondary={
                <Box component="span" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  {job.companyName}
                  <Box component="span" sx={{ mx: 0.5, color: 'text.disabled' }}>•</Box>
                  {new Date(job.applicationDate).toLocaleDateString()}
                </Box>
              }
            />
            <ListItemSecondaryAction>
              <Chip
                label={formatStatus(job.status)}
                color={getStatusColor(job.status)}
                size="small"
                variant="outlined"
                sx={{ fontWeight: 500 }}
              />
            </ListItemSecondaryAction>
          </ListItem>
          {index < applications.length - 1 && <Divider variant="inset" component="li" />}
        </React.Fragment>
      ))}
    </List>
  );
};

export default RecentApplications;