import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink } from 'react-router-dom';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Button,
  Box,
  CircularProgress,
  Card,
  CardContent,
  CardHeader,
  Divider,
  IconButton,
  Tooltip,
  Avatar,
  LinearProgress
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RefreshIcon from '@mui/icons-material/Refresh';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import WorkIcon from '@mui/icons-material/Work';
import EventNoteIcon from '@mui/icons-material/EventNote';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import { alpha } from '@mui/material/styles';
import { fetchJobs } from '../../slices/jobSlice';
import JobStatusChart from './JobStatusChart';
import RecentApplications from './RecentApplications';
import UpcomingInterviews from './UpcomingInterviews';

const Dashboard = () => {
  const dispatch = useDispatch();
  const { jobs, status, error } = useSelector(state => state.jobs);
  const { user } = useSelector(state => state.auth);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchJobs());
    }
  }, [status, dispatch]);

  // Ensure jobs is always an array
  const jobsArray = Array.isArray(jobs) ? jobs : [];
  
  // Calculate stats
  const totalJobs = jobsArray.length;
  const applied = jobsArray.filter(job => job.status === 'APPLIED').length;
  const interviews = jobsArray.filter(job => 
    job.status === 'INTERVIEW_SCHEDULED' || job.status === 'INTERVIEW_COMPLETED'
  ).length;
  const offers = jobsArray.filter(job => job.status === 'OFFER_RECEIVED').length;
  const rejections = jobsArray.filter(job => job.status === 'REJECTED').length;
  
  // Calculate percentages for progress bars
  const interviewRate = totalJobs ? Math.round((interviews / totalJobs) * 100) : 0;
  const offerRate = totalJobs ? Math.round((offers / totalJobs) * 100) : 0;
  
  // Extract upcoming interviews from job data
  const upcomingInterviews = [];
  
  // Process jobs to extract interviews
  jobsArray.forEach(job => {
    // Check if job has INTERVIEW_SCHEDULED status but no interviews array
    if (job.status === 'INTERVIEW_SCHEDULED' && (!job.interviews || job.interviews.length === 0)) {
      // For jobs with INTERVIEW_SCHEDULED status but no interview data, 
      // create a placeholder interview based on job details
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(10, 0, 0, 0); // 10:00 AM
      
      upcomingInterviews.push({
        id: `interview-${job.id}-placeholder`,
        type: 'ONSITE', // Default type
        interviewDate: tomorrow,
        location: job.location || 'Not specified',
        jobApplication: {
          id: job.id,
          jobTitle: job.jobTitle,
          companyName: job.companyName
        }
      });
    }
    
    // Process actual interview objects if they exist
    if (job.interviews && job.interviews.length > 0) {
      // Filter for upcoming interviews (interviews in the future)
      const now = new Date();
      job.interviews.forEach(interview => {
        // Handle various field names for interview date and ensure it's properly parsed
        let interviewDate;
        if (interview.interviewDate) {
          interviewDate = interview.interviewDate instanceof Date ? 
            interview.interviewDate : 
            new Date(interview.interviewDate);
        } else if (interview.date) {
          interviewDate = new Date(interview.date);
        } else if (interview.dateTime) {
          interviewDate = new Date(interview.dateTime);
        } else {
          // Skip if no valid date
          return;
        }
        
        // Only include future interviews
        if (interviewDate > now) {
          upcomingInterviews.push({
            id: interview.id || `interview-${job.id}-${Math.random().toString(36).substr(2, 9)}`,
            type: interview.interviewType || interview.type || 'ONSITE',
            interviewDate: interviewDate,
            location: interview.location || 'Not specified',
            jobApplication: {
              id: job.id,
              jobTitle: job.jobTitle,
              companyName: job.companyName
            }
          });
        }
      });
    }
  });
  
  // Sort upcoming interviews by date (soonest first)
  upcomingInterviews.sort((a, b) => a.interviewDate - b.interviewDate);
  
  // Sort jobs by date for recent applications
  const recentJobs = [...jobsArray]
    .sort((a, b) => new Date(b.applicationDate) - new Date(a.applicationDate))
    .slice(0, 5);

  const handleRefresh = () => {
    setIsRefreshing(true);
    dispatch(fetchJobs()).finally(() => {
      setTimeout(() => setIsRefreshing(false), 1000);
    });
  };

  if (status === 'loading' && !isRefreshing) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh" flexDirection="column">
        <CircularProgress size={60} thickness={4} />
        <Typography variant="h6" sx={{ mt: 2 }}>Loading your dashboard...</Typography>
      </Box>
    );
  }

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' }}>
        <Box>
          <Typography variant="h4" component="h1" fontWeight="bold">
            Dashboard
          </Typography>
          <Typography variant="subtitle1" color="text.secondary" sx={{ mb: 1 }}>
            Welcome back, {user?.username || 'User'}!
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Tooltip title="Refresh data">
            <IconButton onClick={handleRefresh} disabled={isRefreshing}>
              <RefreshIcon />
            </IconButton>
          </Tooltip>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            component={RouterLink}
            to="/jobs/add"
            size="medium"
          >
            Add New Job
          </Button>
        </Box>
      </Box>

      {isRefreshing && (
        <LinearProgress sx={{ mb: 3, borderRadius: 1 }} />
      )}

      {error ? (
        <Paper sx={{ p: 3, mb: 4, bgcolor: 'error.light', color: 'error.contrastText', borderRadius: 2 }}>
          <Typography variant="body1">Error loading your job applications: {error}</Typography>
        </Paper>
      ) : (
        <>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Card elevation={2} sx={{ height: '100%' }}>
                <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 3 }}>
                  <Avatar sx={{ bgcolor: alpha('#1976d2', 0.1), color: 'primary.main', width: 56, height: 56, mb: 2 }}>
                    <WorkIcon fontSize="large" />
                  </Avatar>
                  <Typography variant="h6" color="text.secondary" gutterBottom>Total Applications</Typography>
                  <Typography variant="h3" fontWeight="bold">{totalJobs}</Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card elevation={2} sx={{ height: '100%' }}>
                <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 3 }}>
                  <Avatar sx={{ bgcolor: alpha('#1976d2', 0.1), color: 'primary.main', width: 56, height: 56, mb: 2 }}>
                    <TrendingUpIcon fontSize="large" />
                  </Avatar>
                  <Typography variant="h6" color="text.secondary" gutterBottom>In Progress</Typography>
                  <Typography variant="h3" fontWeight="bold">{applied}</Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card elevation={2} sx={{ height: '100%' }}>
                <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 3 }}>
                  <Avatar sx={{ bgcolor: alpha('#ff9800', 0.1), color: 'warning.main', width: 56, height: 56, mb: 2 }}>
                    <EventNoteIcon fontSize="large" />
                  </Avatar>
                  <Typography variant="h6" color="text.secondary" gutterBottom>Interviews</Typography>
                  <Typography variant="h3" fontWeight="bold">{interviews}</Typography>
                  <Box sx={{ width: '100%', mt: 1 }}>
                    <Typography variant="caption" color="text.secondary" align="center" display="block">
                      {interviewRate}% of applications
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={interviewRate} 
                      color="warning" 
                      sx={{ height: 6, borderRadius: 3, mt: 0.5 }}
                    />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card elevation={2} sx={{ height: '100%' }}>
                <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 3 }}>
                  <Avatar sx={{ bgcolor: alpha('#4caf50', 0.1), color: 'success.main', width: 56, height: 56, mb: 2 }}>
                    <EmojiEventsIcon fontSize="large" />
                  </Avatar>
                  <Typography variant="h6" color="text.secondary" gutterBottom>Offers</Typography>
                  <Typography variant="h3" fontWeight="bold">{offers}</Typography>
                  <Box sx={{ width: '100%', mt: 1 }}>
                    <Typography variant="caption" color="text.secondary" align="center" display="block">
                      {offerRate}% of applications
                    </Typography>
                    <LinearProgress 
                      variant="determinate" 
                      value={offerRate} 
                      color="success" 
                      sx={{ height: 6, borderRadius: 3, mt: 0.5 }}
                    />
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>

          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card elevation={2} sx={{ height: '100%' }}>
                <CardHeader 
                  title="Recent Applications" 
                  titleTypographyProps={{ variant: 'h6' }}
                />
                <Divider />
                <CardContent sx={{ pt: 2 }}>
                  <RecentApplications applications={recentJobs} />
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card elevation={2} sx={{ height: '100%' }}>
                <CardHeader 
                  title="Application Status" 
                  titleTypographyProps={{ variant: 'h6' }}
                />
                <Divider />
                <CardContent sx={{ pt: 2 }}>
                  <Box sx={{ height: 300, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    {totalJobs > 0 ? (
                      <JobStatusChart
                        applied={applied}
                        interviews={interviews}
                        offers={offers}
                        rejections={rejections}
                      />
                    ) : (
                      <Typography variant="body2" color="text.secondary" align="center">
                        No data to display. Add job applications to see statistics.
                      </Typography>
                    )}
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12}>
              <Card elevation={2}>
                <CardHeader 
                  title="Upcoming Interviews" 
                  titleTypographyProps={{ variant: 'h6' }}
                />
                <Divider />
                <CardContent sx={{ pt: 2 }}>
                  <UpcomingInterviews interviews={upcomingInterviews} />
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </>
      )}
    </Container>
  );
};

export default Dashboard;