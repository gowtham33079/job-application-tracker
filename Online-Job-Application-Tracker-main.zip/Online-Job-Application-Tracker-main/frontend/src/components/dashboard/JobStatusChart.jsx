import React from 'react';
import { Box, useTheme, Typography } from '@mui/material';
import { PieChart, Pie, Cell, Legend, Tooltip } from 'recharts';

/**
 * Component to display job application statistics in a pie chart
 * @param {Object} props Component props
 * @param {number} props.applied Number of applications in "Applied" status
 * @param {number} props.interviews Number of applications in interview stages
 * @param {number} props.offers Number of applications with offers received
 * @param {number} props.rejections Number of rejected applications
 */
const JobStatusChart = ({ applied = 0, interviews = 0, offers = 0, rejections = 0 }) => {
  const theme = useTheme();

  // Ensure numeric values
  const safeApplied = parseInt(applied) || 0;
  const safeInterviews = parseInt(interviews) || 0;
  const safeOffers = parseInt(offers) || 0;
  const safeRejections = parseInt(rejections) || 0;
  
  // Define the chart data with colors based on the theme
  const data = [
    { name: 'Applied', value: safeApplied, color: theme.palette.primary.main },
    { name: 'Interviews', value: safeInterviews, color: theme.palette.warning.main },
    { name: 'Offers', value: safeOffers, color: theme.palette.success.main },
    { name: 'Rejected', value: safeRejections, color: theme.palette.error.main }
  ].filter(item => item.value > 0); // Only include non-zero values

  // If no data, show a message
  if (data.length === 0) {
    return (
      <Box sx={{ height: 300, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <Typography variant="body2" color="text.secondary">
          No application status data to display.
        </Typography>
      </Box>
    );
  }

  // Calculate total for percentages
  const total = data.reduce((sum, entry) => sum + entry.value, 0);

  // Custom renderer for the legend
  const renderLegend = (props) => {
    const { payload } = props;
    
    return (
      <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
        {payload.map((entry, index) => {
          const percentage = ((entry.payload.value / total) * 100).toFixed(1);
          return (
            <Box 
              key={`legend-item-${index}`}
              sx={{ display: 'flex', alignItems: 'center', mb: 1 }}
            >
              <Box
                component="span"
                sx={{
                  width: 14,
                  height: 14,
                  borderRadius: '50%',
                  bgcolor: entry.color,
                  mr: 1,
                  display: 'inline-block'
                }}
              />
              <Box component="span" sx={{ mr: 1 }}>
                {entry.value}:
              </Box>
              <Box component="span" sx={{ fontWeight: 'medium' }}>
                {entry.payload.value} ({percentage}%)
              </Box>
            </Box>
          );
        })}
      </Box>
    );
  };

  // Use a fixed-size chart instead of ResponsiveContainer
  return (
    <Box sx={{ width: '100%', height: 300, display: 'flex', justifyContent: 'center' }}>
      <PieChart width={400} height={300}>
        <Pie
          data={data}
          cx={200}
          cy={120}
          labelLine={false}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
          animationDuration={750}
          animationBegin={0}
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip 
          formatter={(value, name) => {
            const percentage = ((value / total) * 100).toFixed(1);
            return [`${value} (${percentage}%)`, name];
          }}
        />
        <Legend content={renderLegend} verticalAlign="bottom" align="center" />
      </PieChart>
    </Box>
  );
};

export default JobStatusChart;