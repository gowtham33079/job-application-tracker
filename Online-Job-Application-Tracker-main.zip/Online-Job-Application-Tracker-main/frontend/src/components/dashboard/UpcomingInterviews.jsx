import React from 'react';
import { 
  List, 
  ListItem, 
  ListItemText, 
  ListItemAvatar, 
  ListItemSecondaryAction,
  Avatar, 
  Box,
  Typography, 
  Chip,
  IconButton,
  Tooltip,
  Divider,
  Stack
} from '@mui/material';
import { 
  Event as EventIcon, 
  Videocam as VideocamIcon,
  LocationOn as LocationIcon,
  OpenInNew as OpenInNewIcon,
  InsertInvitation as CalendarIcon
} from '@mui/icons-material';
import { Link as RouterLink } from 'react-router-dom';
import { format } from 'date-fns';

/**
 * Component to display upcoming interviews on the dashboard
 * @param {Object} props Component props
 * @param {Array} props.interviews Array of upcoming interviews to display
 */
const UpcomingInterviews = ({ interviews = [] }) => {
  
  // Formats the date and time for display
  const formatDateTime = (dateTime) => {
    if (!dateTime) return '';
    const date = new Date(dateTime);
    return format(date, 'MMM dd, yyyy - h:mm a');
  };

  // Format interview type for display
  const formatInterviewType = (type) => {
    if (!type) return '';
    return type.replace('_', ' ').replace(/\b\w/g, (l) => l.toUpperCase());
  };
  
  // If no interviews, show a message
  if (!interviews || interviews.length === 0) {
    return (
      <Box 
        sx={{ 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center', 
          justifyContent: 'center', 
          py: 4 
        }}
      >
        <CalendarIcon 
          sx={{ 
            fontSize: 48, 
            color: 'text.disabled', 
            mb: 2 
          }} 
        />
        <Typography variant="body1" color="text.secondary" align="center">
          No upcoming interviews
        </Typography>
        <Typography variant="body2" color="text.disabled" align="center" sx={{ mt: 1 }}>
          When you schedule interviews, they will appear here
        </Typography>
      </Box>
    );
  }

  return (
    <List disablePadding>
      {interviews.map((interview, index) => (
        <React.Fragment key={interview.id}>
          <ListItem 
            alignItems="flex-start"
            sx={{ 
              py: 2,
              borderRadius: 1,
            }}
          >
            <ListItemAvatar>
              <Avatar 
                sx={{ 
                  bgcolor: interview.type === 'VIDEO' ? 'info.light' : 'success.light',
                  width: 40,
                  height: 40
                }}
              >
                {interview.type === 'VIDEO' ? <VideocamIcon /> : <EventIcon />}
              </Avatar>
            </ListItemAvatar>
            <ListItemText
              primary={
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                  <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                    {interview.jobApplication ? interview.jobApplication.companyName : 'Interview'}
                  </Typography>
                  <Chip
                    label={formatInterviewType(interview.type)}
                    color={interview.type === 'VIDEO' ? 'info' : 'success'}
                    size="small"
                    sx={{ ml: 1, height: 20, fontSize: '0.7rem' }}
                  />
                </Box>
              }
              secondary={
                <Stack spacing={0.5}>
                  <Typography variant="body2" color="text.primary">
                    {interview.jobApplication ? interview.jobApplication.jobTitle : 'Position'}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                    <EventIcon fontSize="small" sx={{ mr: 0.5, color: 'text.secondary', fontSize: '0.9rem' }} />
                    <Typography variant="caption" color="text.secondary">
                      {formatDateTime(interview.interviewDate)}
                    </Typography>
                  </Box>
                  {interview.location && (
                    <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                      <LocationIcon fontSize="small" sx={{ mr: 0.5, color: 'text.secondary', fontSize: '0.9rem' }} />
                      <Typography variant="caption" color="text.secondary">
                        {interview.location}
                      </Typography>
                    </Box>
                  )}
                </Stack>
              }
            />
            <ListItemSecondaryAction>
              <Tooltip title="View job details">
                <IconButton 
                  edge="end" 
                  component={RouterLink} 
                  to={`/jobs/${interview.jobApplication ? interview.jobApplication.id : ''}`}
                  size="small"
                >
                  <OpenInNewIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </ListItemSecondaryAction>
          </ListItem>
          {index < interviews.length - 1 && <Divider variant="inset" />}
        </React.Fragment>
      ))}
    </List>
  );
};

export default UpcomingInterviews;