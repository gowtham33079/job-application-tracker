import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import {
  Container,
  Typography,
  Box,
  Paper,
  Switch,
  FormControlLabel,
  Divider,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  TextField
} from '@mui/material';
import {
  Notifications as NotificationsIcon,
  Visibility as VisibilityIcon,
  Lock as LockIcon,
  Email as EmailIcon,
  Delete as DeleteIcon
} from '@mui/icons-material';

const Settings = () => {
  const { user } = useSelector(state => state.auth);
  
  // State for settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [applicationReminders, setApplicationReminders] = useState(true);
  const [interviewReminders, setInterviewReminders] = useState(true);
  const [publicProfile, setPublicProfile] = useState(false);
  
  // State for feedback
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  
  // State for dialogs
  const [passwordDialog, setPasswordDialog] = useState(false);
  const [emailDialog, setEmailDialog] = useState(false);
  const [deleteDialog, setDeleteDialog] = useState(false);
  
  // Handle settings changes
  const handleSave = () => {
    // In a real app, you would send these settings to the backend
    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
  };
  
  // Handle dialog opens and closes
  const handlePasswordDialogOpen = () => setPasswordDialog(true);
  const handlePasswordDialogClose = () => setPasswordDialog(false);
  
  const handleEmailDialogOpen = () => setEmailDialog(true);
  const handleEmailDialogClose = () => setEmailDialog(false);
  
  const handleDeleteDialogOpen = () => setDeleteDialog(true);
  const handleDeleteDialogClose = () => setDeleteDialog(false);
  
  return (
    <Container maxWidth="md">
      <Typography variant="h4" component="h1" gutterBottom fontWeight="bold">
        Account Settings
      </Typography>
      
      {success && (
        <Alert severity="success" sx={{ mb: 3 }}>
          Settings updated successfully!
        </Alert>
      )}
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Notification Preferences
        </Typography>
        <Divider sx={{ mb: 2 }} />
        
        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
          <FormControlLabel
            control={
              <Switch
                checked={emailNotifications}
                onChange={(e) => setEmailNotifications(e.target.checked)}
                color="primary"
              />
            }
            label="Email Notifications"
          />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 4, mb: 2 }}>
            Receive emails about important updates and account activity
          </Typography>
          
          <FormControlLabel
            control={
              <Switch
                checked={applicationReminders}
                onChange={(e) => setApplicationReminders(e.target.checked)}
                color="primary"
              />
            }
            label="Job Application Reminders"
          />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 4, mb: 2 }}>
            Receive reminders about upcoming follow-up dates
          </Typography>
          
          <FormControlLabel
            control={
              <Switch
                checked={interviewReminders}
                onChange={(e) => setInterviewReminders(e.target.checked)}
                color="primary"
              />
            }
            label="Interview Reminders"
          />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 4, mb: 2 }}>
            Receive reminders about upcoming interviews
          </Typography>
        </Box>
      </Paper>
      
      <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Privacy Settings
        </Typography>
        <Divider sx={{ mb: 2 }} />
        
        <Box>
          <FormControlLabel
            control={
              <Switch
                checked={publicProfile}
                onChange={(e) => setPublicProfile(e.target.checked)}
                color="primary"
              />
            }
            label="Public Profile"
          />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 4, mb: 2 }}>
            Allow others to view your public profile (Note: your job applications remain private)
          </Typography>
        </Box>
      </Paper>
      
      <Paper elevation={3} sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Account Management
        </Typography>
        <Divider sx={{ mb: 2 }} />
        
        <List>
          <ListItem button onClick={handlePasswordDialogOpen}>
            <ListItemIcon>
              <LockIcon />
            </ListItemIcon>
            <ListItemText 
              primary="Change Password" 
              secondary="Update your account password"
            />
          </ListItem>
          
          <ListItem button onClick={handleEmailDialogOpen}>
            <ListItemIcon>
              <EmailIcon />
            </ListItemIcon>
            <ListItemText 
              primary="Change Email Address" 
              secondary={user?.email || "Update your email address"}
            />
          </ListItem>
          
          <ListItem button>
            <ListItemIcon sx={{ color: 'error.main' }}>
              <DeleteIcon />
            </ListItemIcon>
            <ListItemText 
              primary="Delete Account" 
              secondary="Permanently delete your account and all data"
              primaryTypographyProps={{ color: 'error' }}
            />
            <ListItemSecondaryAction>
              <Button 
                variant="outlined" 
                color="error" 
                size="small"
                onClick={handleDeleteDialogOpen}
              >
                Delete
              </Button>
            </ListItemSecondaryAction>
          </ListItem>
        </List>
      </Paper>
      
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
        <Button variant="contained" color="primary" onClick={handleSave}>
          Save Settings
        </Button>
      </Box>
      
      {/* Change Password Dialog */}
      <Dialog open={passwordDialog} onClose={handlePasswordDialogClose}>
        <DialogTitle>Change Password</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Enter your current password and a new password to update your credentials.
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            label="Current Password"
            type="password"
            fullWidth
            variant="outlined"
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="New Password"
            type="password"
            fullWidth
            variant="outlined"
            sx={{ mb: 2 }}
          />
          <TextField
            margin="dense"
            label="Confirm New Password"
            type="password"
            fullWidth
            variant="outlined"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handlePasswordDialogClose}>Cancel</Button>
          <Button variant="contained" onClick={handlePasswordDialogClose}>Update Password</Button>
        </DialogActions>
      </Dialog>
      
      {/* Change Email Dialog */}
      <Dialog open={emailDialog} onClose={handleEmailDialogClose}>
        <DialogTitle>Change Email Address</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 2 }}>
            Enter your new email address. You will need to verify this email before the change takes effect.
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            label="New Email Address"
            type="email"
            fullWidth
            variant="outlined"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleEmailDialogClose}>Cancel</Button>
          <Button variant="contained" onClick={handleEmailDialogClose}>Update Email</Button>
        </DialogActions>
      </Dialog>
      
      {/* Delete Account Dialog */}
      <Dialog open={deleteDialog} onClose={handleDeleteDialogClose}>
        <DialogTitle sx={{ color: 'error.main' }}>Delete Account</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete your account? This action cannot be undone and will permanently delete all your data, including job applications, notes, and settings.
          </DialogContentText>
          <TextField
            margin="dense"
            label="Type 'DELETE' to confirm"
            fullWidth
            variant="outlined"
            sx={{ mt: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteDialogClose}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDeleteDialogClose}>Delete Account</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default Settings;