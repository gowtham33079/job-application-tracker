import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  Container,
  Typography,
  Box,
  Paper,
  Avatar,
  Button,
  Divider,
  TextField,
  Grid,
  Alert,
  Card,
  CardContent,
  IconButton
} from '@mui/material';
import {
  Edit as EditIcon,
  Badge as BadgeIcon,
  Save as SaveIcon,
  Cancel as CancelIcon
} from '@mui/icons-material';
import { alpha } from '@mui/material/styles';

const Profile = () => {
  const { user } = useSelector(state => state.auth);
  const { jobs } = useSelector(state => state.jobs);
  const [editing, setEditing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  
  const [profile, setProfile] = useState({
    username: user?.username || '',
    email: user?.email || '',
    firstName: '',
    lastName: '',
    location: '',
    bio: '',
  });
  
  // Calculate job statistics
  const jobsArray = Array.isArray(jobs) ? jobs : [];
  const totalApplications = jobsArray.length;
  const interviews = jobsArray.filter(job => 
    job.status === 'INTERVIEW_SCHEDULED' || job.status === 'INTERVIEW_COMPLETED'
  ).length;
  const offers = jobsArray.filter(job => job.status === 'OFFER_RECEIVED').length;
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile({
      ...profile,
      [name]: value
    });
  };
  
  const handleEdit = () => {
    setEditing(true);
    setSuccess(false);
    setError(null);
  };
  
  const handleCancel = () => {
    setEditing(false);
    setProfile({
      username: user?.username || '',
      email: user?.email || '',
      firstName: '',
      lastName: '',
      location: '',
      bio: ''
    });
  };
  
  const handleSave = () => {
    // In a real application, you would save the profile data to the backend
    // For now, we'll just simulate a successful save
    setTimeout(() => {
      setEditing(false);
      setSuccess(true);
    }, 1000);
  };
  
  return (
    <Container maxWidth="md">
      <Typography variant="h4" component="h1" gutterBottom fontWeight="bold">
        My Profile
      </Typography>
      
      {success && (
        <Alert severity="success" sx={{ mb: 3 }}>
          Profile updated successfully!
        </Alert>
      )}
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={4}>
          <Card elevation={3}>
            <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', p: 3 }}>
              <Box sx={{ position: 'relative' }}>
                <Avatar 
                  sx={{ 
                    width: 120, 
                    height: 120, 
                    fontSize: 48,
                    bgcolor: 'primary.main',
                    boxShadow: 2
                  }}
                >
                  {user?.username?.charAt(0).toUpperCase() || 'U'}
                </Avatar>
                <IconButton 
                  sx={{ 
                    position: 'absolute', 
                    bottom: 0, 
                    right: 0,
                    bgcolor: 'background.paper',
                    boxShadow: 1
                  }}
                >
                  <BadgeIcon fontSize="small" />
                </IconButton>
              </Box>
              
              <Typography variant="h5" sx={{ mt: 2 }}>
                {user?.username || 'Username'}
              </Typography>
              
              <Typography variant="body2" color="text.secondary" align="center">
                {user?.email || 'user@example.com'}
              </Typography>
              
              <Button 
                variant="outlined" 
                startIcon={<EditIcon />} 
                sx={{ mt: 3 }}
                onClick={handleEdit}
                disabled={editing}
              >
                Edit Profile
              </Button>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={8}>
          <Paper elevation={3} sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6">Profile Information</Typography>
              {editing && (
                <Box>
                  <Button 
                    startIcon={<SaveIcon />} 
                    variant="contained" 
                    sx={{ mr: 1 }}
                    onClick={handleSave}
                  >
                    Save
                  </Button>
                  <Button 
                    startIcon={<CancelIcon />} 
                    variant="outlined"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </Box>
              )}
            </Box>
            
            <Divider sx={{ mb: 3 }} />
            
            <Grid container spacing={3}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="First Name"
                  name="firstName"
                  value={profile.firstName}
                  onChange={handleInputChange}
                  disabled={!editing}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Last Name"
                  name="lastName"
                  value={profile.lastName}
                  onChange={handleInputChange}
                  disabled={!editing}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Username"
                  name="username"
                  value={profile.username}
                  onChange={handleInputChange}
                  disabled={true} // Username should not be editable
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Email Address"
                  name="email"
                  value={profile.email}
                  onChange={handleInputChange}
                  disabled={true} // Email should not be editable
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Location"
                  name="location"
                  placeholder="City, Country"
                  value={profile.location}
                  onChange={handleInputChange}
                  disabled={!editing}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Bio"
                  name="bio"
                  multiline
                  rows={4}
                  value={profile.bio}
                  onChange={handleInputChange}
                  disabled={!editing}
                  placeholder="Tell us a bit about yourself..."
                />
              </Grid>
            </Grid>
          </Paper>
          
          <Paper elevation={3} sx={{ p: 3, mt: 3 }}>
            <Typography variant="h6" gutterBottom>Account Statistics</Typography>
            <Divider sx={{ mb: 3 }} />
            
            <Grid container spacing={3}>
              <Grid item xs={12} sm={4}>
                <Box 
                  sx={{ 
                    p: 2, 
                    textAlign: 'center',
                    bgcolor: alpha('#2196f3', 0.1),
                    borderRadius: 2
                  }}
                >
                  <Typography variant="h4" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                    {totalApplications}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Total Applications
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box 
                  sx={{ 
                    p: 2, 
                    textAlign: 'center',
                    bgcolor: alpha('#ff9800', 0.1),
                    borderRadius: 2
                  }}
                >
                  <Typography variant="h4" sx={{ fontWeight: 'bold', color: 'warning.main' }}>
                    {interviews}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Interviews
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box 
                  sx={{ 
                    p: 2, 
                    textAlign: 'center',
                    bgcolor: alpha('#4caf50', 0.1),
                    borderRadius: 2
                  }}
                >
                  <Typography variant="h4" sx={{ fontWeight: 'bold', color: 'success.main' }}>
                    {offers}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Offers
                  </Typography>
                </Box>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Profile;