import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link as RouterLink, useNavigate, useLocation } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  Box,
  Menu,
  MenuItem,
  Divider,
  ListItemIcon,
  Avatar,
  Tooltip,
  Drawer,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  useMediaQuery,
  Badge
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  Work as WorkIcon,
  Logout as LogoutIcon,
  AccountCircle as AccountCircleIcon,
  Settings as SettingsIcon,
  Add as AddIcon,
  Notifications as NotificationsIcon
} from '@mui/icons-material';
import { logout } from '../../slices/authSlice';
import { alpha, useTheme } from '@mui/material/styles';
import { format } from 'date-fns';

const Header = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  const { isLoggedIn, user } = useSelector(state => state.auth);
  const { jobs } = useSelector(state => state.jobs);

  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [anchorElNotifications, setAnchorElNotifications] = useState(null);
  const [notifications, setNotifications] = useState([]);

  // Generate notifications from jobs data
  useEffect(() => {
    if (isLoggedIn && Array.isArray(jobs) && jobs.length > 0) {
      const jobNotifications = [];
      
      // Upcoming interviews
      const interviewJobs = jobs.filter(job => 
        job.status === 'INTERVIEW_SCHEDULED' || 
        (job.interviews && job.interviews.length > 0)
      );
      
      interviewJobs.forEach(job => {
        if (job.interviews && job.interviews.length > 0) {
          job.interviews.forEach(interview => {
            const interviewDate = new Date(interview.interviewDate);
            const now = new Date();
            const twoDaysFromNow = new Date();
            twoDaysFromNow.setDate(now.getDate() + 2);
            
            if (interviewDate > now && interviewDate < twoDaysFromNow) {
              jobNotifications.push({
                id: `interview-${job.id}-${interview.id}`,
                type: 'INTERVIEW',
                title: `Upcoming interview at ${job.companyName}`,
                message: `Interview for ${job.jobTitle} position on ${format(interviewDate, 'MMM dd')}`,
                date: interviewDate,
                read: false
              });
            }
          });
        } else if (job.status === 'INTERVIEW_SCHEDULED') {
          jobNotifications.push({
            id: `interview-status-${job.id}`,
            type: 'INTERVIEW',
            title: `Interview scheduled`,
            message: `For ${job.jobTitle} at ${job.companyName}`,
            date: new Date(),
            read: false
          });
        }
      });
      
      // Follow-up reminders
      const followUpJobs = jobs.filter(job => job.followUpDate);
      followUpJobs.forEach(job => {
        const followUpDate = new Date(job.followUpDate);
        const now = new Date();
        const dayDiff = Math.ceil((followUpDate - now) / (1000 * 60 * 60 * 24));
        
        if (dayDiff >= 0 && dayDiff <= 1) {
          jobNotifications.push({
            id: `followup-${job.id}`,
            type: 'REMINDER',
            title: `Follow up reminder`,
            message: `Follow up with ${job.companyName} ${dayDiff === 0 ? 'today' : 'tomorrow'}`,
            date: followUpDate,
            read: false
          });
        }
      });
      
      // Status changes
      const statusChanges = jobs.filter(job => job.status === 'OFFER_RECEIVED' || job.status === 'REJECTED')
        .slice(0, 2);
      
      statusChanges.forEach(job => {
        jobNotifications.push({
          id: `status-${job.id}`,
          type: 'STATUS',
          title: `Status update`,
          message: `${job.companyName}: ${job.status.replace('_', ' ')}`,
          date: new Date(),
          read: false
        });
      });
      
      // Sort by date (newest first) and take only the most recent notifications
      const sortedNotifications = jobNotifications
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 5);
      
      setNotifications(sortedNotifications);
    }
  }, [isLoggedIn, jobs]);

  // Add active link tracking
  const isActiveRoute = (path) => location.pathname === path;

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };
  
  const handleOpenNotifications = (event) => {
    setAnchorElNotifications(event.currentTarget);
  };

  const handleCloseNotifications = () => {
    setAnchorElNotifications(null);
  };

  const handleViewNotification = (path) => {
    handleCloseNotifications();
    navigate(path);
  };

  const handleLogout = () => {
    dispatch(logout());
    handleCloseUserMenu();
    navigate('/login');
  };

  // Mobile drawer content
  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
      <Typography variant="h6" sx={{ my: 2, fontWeight: 700 }}>
        JobTracker
      </Typography>
      <Divider />
      {isLoggedIn ? (
        <List>
          <ListItem disablePadding>
            <ListItemButton 
              component={RouterLink} 
              to="/" 
              sx={{
                bgcolor: isActiveRoute('/') ? alpha(theme.palette.primary.main, 0.1) : 'transparent',
                color: isActiveRoute('/') ? 'primary.main' : 'inherit',
              }}
            >
              <ListItemIcon>
                <DashboardIcon color={isActiveRoute('/') ? 'primary' : 'inherit'} />
              </ListItemIcon>
              <ListItemText primary="Dashboard" />
            </ListItemButton>
          </ListItem>
          
          <ListItem disablePadding>
            <ListItemButton 
              component={RouterLink} 
              to="/jobs" 
              sx={{
                bgcolor: isActiveRoute('/jobs') ? alpha(theme.palette.primary.main, 0.1) : 'transparent',
                color: isActiveRoute('/jobs') ? 'primary.main' : 'inherit',
              }}
            >
              <ListItemIcon>
                <WorkIcon color={isActiveRoute('/jobs') ? 'primary' : 'inherit'} />
              </ListItemIcon>
              <ListItemText primary="My Applications" />
            </ListItemButton>
          </ListItem>
          
          <ListItem disablePadding>
            <ListItemButton 
              component={RouterLink}
              to="/jobs/add"
              sx={{
                bgcolor: isActiveRoute('/jobs/add') ? alpha(theme.palette.primary.main, 0.1) : 'transparent',
                color: isActiveRoute('/jobs/add') ? 'primary.main' : 'inherit',
              }}
            >
              <ListItemIcon>
                <AddIcon color={isActiveRoute('/jobs/add') ? 'primary' : 'inherit'} />
              </ListItemIcon>
              <ListItemText primary="Add Application" />
            </ListItemButton>
          </ListItem>
        </List>
      ) : (
        <List>
          <ListItem disablePadding>
            <ListItemButton component={RouterLink} to="/login">
              <ListItemText primary="Login" />
            </ListItemButton>
          </ListItem>
          <ListItem disablePadding>
            <ListItemButton component={RouterLink} to="/register">
              <ListItemText primary="Register" />
            </ListItemButton>
          </ListItem>
        </List>
      )}
    </Box>
  );

  return (
    <>
      <AppBar position="fixed" elevation={1} sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
        <Toolbar>
          {/* Logo / Brand */}
          <Typography
            variant="h6"
            component={RouterLink}
            to="/"
            sx={{
              mr: 2,
              fontWeight: 700,
              color: 'white',
              textDecoration: 'none',
              flexGrow: { xs: 1, md: 0 }
            }}
          >
            JobTracker
          </Typography>

          {isLoggedIn && isMobile && (
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              onClick={handleDrawerToggle}
              sx={{ display: { md: 'none' } }}
            >
              <MenuIcon />
            </IconButton>
          )}

          {isLoggedIn ? (
            <>
              {/* Desktop Navigation Links */}
              <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' }, ml: 2 }}>
                <Button
                  component={RouterLink}
                  to="/"
                  sx={{ 
                    my: 2, 
                    color: 'white',
                    background: isActiveRoute('/') ? alpha('#ffffff', 0.2) : 'transparent',
                    '&:hover': {
                      background: alpha('#ffffff', 0.1)
                    }
                  }}
                  startIcon={<DashboardIcon />}
                >
                  Dashboard
                </Button>
                <Button
                  component={RouterLink}
                  to="/jobs"
                  sx={{ 
                    my: 2, 
                    color: 'white',
                    background: isActiveRoute('/jobs') ? alpha('#ffffff', 0.2) : 'transparent',
                    '&:hover': {
                      background: alpha('#ffffff', 0.1)
                    }
                  }}
                  startIcon={<WorkIcon />}
                >
                  Applications
                </Button>
                <Button
                  component={RouterLink}
                  to="/jobs/add"
                  sx={{ 
                    my: 2, 
                    color: 'white',
                    background: isActiveRoute('/jobs/add') ? alpha('#ffffff', 0.2) : 'transparent',
                    '&:hover': {
                      background: alpha('#ffffff', 0.1)
                    }
                  }}
                  startIcon={<AddIcon />}
                >
                  Add New
                </Button>
              </Box>

              {/* Notifications Icon */}
              <Box sx={{ flexGrow: 0, mr: 2 }}>
                <Tooltip title="Notifications">
                  <IconButton onClick={handleOpenNotifications} sx={{ color: 'white' }}>
                    <Badge badgeContent={notifications.length} color="error">
                      <NotificationsIcon />
                    </Badge>
                  </IconButton>
                </Tooltip>
                <Menu
                  sx={{ mt: '45px' }}
                  anchorEl={anchorElNotifications}
                  anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  open={Boolean(anchorElNotifications)}
                  onClose={handleCloseNotifications}
                >
                  {notifications.length > 0 ? (
                    <>
                      {notifications.map((notification) => (
                        <MenuItem 
                          key={notification.id}
                          onClick={() => handleViewNotification(`/jobs/${notification.id.split('-')[1]}`)}
                        >
                          <Box sx={{ maxWidth: '300px' }}>
                            <Typography variant="subtitle2" noWrap>
                              {notification.title}
                            </Typography>
                            <Typography variant="caption" color="text.secondary" noWrap>
                              {notification.message}
                            </Typography>
                          </Box>
                        </MenuItem>
                      ))}
                      <Divider />
                    </>
                  ) : (
                    <MenuItem sx={{ justifyContent: 'center', color: 'text.secondary' }}>
                      <Typography variant="body2">No new notifications</Typography>
                    </MenuItem>
                  )}
                  <MenuItem 
                    onClick={() => {
                      handleCloseNotifications();
                      navigate('/notifications');
                    }}
                    sx={{ justifyContent: 'center', color: 'primary.main' }}
                  >
                    <Typography variant="body2">View all notifications</Typography>
                  </MenuItem>
                </Menu>
              </Box>

              {/* User Menu */}
              <Box sx={{ flexGrow: 0 }}>
                <Tooltip title="Account settings">
                  <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                    <Avatar sx={{ bgcolor: 'secondary.main' }}>
                      {user?.username?.charAt(0).toUpperCase() || 'U'}
                    </Avatar>
                  </IconButton>
                </Tooltip>
                <Menu
                  sx={{ mt: '45px' }}
                  id="menu-appbar"
                  anchorEl={anchorElUser}
                  anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  open={Boolean(anchorElUser)}
                  onClose={handleCloseUserMenu}
                >
                  <MenuItem disabled>
                    <Typography textAlign="center">{user?.username || 'User'}</Typography>
                  </MenuItem>
                  <Divider />
                  <MenuItem onClick={() => { handleCloseUserMenu(); navigate('/profile'); }}>
                    <ListItemIcon>
                      <AccountCircleIcon fontSize="small" />
                    </ListItemIcon>
                    Profile
                  </MenuItem>
                  <MenuItem onClick={() => { handleCloseUserMenu(); navigate('/settings'); }}>
                    <ListItemIcon>
                      <SettingsIcon fontSize="small" />
                    </ListItemIcon>
                    Settings
                  </MenuItem>
                  <MenuItem onClick={handleLogout}>
                    <ListItemIcon>
                      <LogoutIcon fontSize="small" />
                    </ListItemIcon>
                    Logout
                  </MenuItem>
                </Menu>
              </Box>
            </>
          ) : (
            // Not logged in - show login/register buttons
            <Box sx={{ flexGrow: 1, display: 'flex', justifyContent: 'flex-end' }}>
              <Button
                component={RouterLink}
                to="/login"
                variant="text"
                sx={{ color: 'white', mr: 1 }}
              >
                Login
              </Button>
              <Button
                component={RouterLink}
                to="/register"
                variant="contained"
                color="secondary"
              >
                Register
              </Button>
            </Box>
          )}
        </Toolbar>
      </AppBar>
      
      {/* Mobile Drawer */}
      {isLoggedIn && (
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true, // Better open performance on mobile.
          }}
          sx={{
            display: { xs: 'block', md: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: 270 },
          }}
        >
          {drawer}
        </Drawer>
      )}
      {/* Empty toolbar to maintain spacing below app bar */}
      <Toolbar />
    </>
  );
};

export default Header;