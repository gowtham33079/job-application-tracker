import React, { Component } from 'react';
import { Box, Container, Typography, Button, Paper } from '@mui/material';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import RefreshIcon from '@mui/icons-material/Refresh';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // You can log the error to an error reporting service
    console.error("Error caught by ErrorBoundary:", error, errorInfo);
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
  }

  handleRefresh = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      // Fallback UI when an error occurs
      return (
        <Container maxWidth="md">
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              minHeight: '100vh',
              py: 5,
              textAlign: 'center'
            }}
          >
            <Paper
              elevation={2}
              sx={{
                p: 4,
                borderRadius: 3,
                maxWidth: '600px',
                width: '100%'
              }}
            >
              <ErrorOutlineIcon sx={{ fontSize: 80, color: 'error.main', mb: 2 }} />
              <Typography variant="h4" gutterBottom fontWeight="bold">
                Something Went Wrong
              </Typography>
              <Typography variant="body1" color="text.secondary" paragraph>
                We apologize for the inconvenience. The application has encountered an unexpected error.
              </Typography>
              
              <Button
                variant="contained"
                color="primary"
                size="large"
                startIcon={<RefreshIcon />}
                onClick={this.handleRefresh}
                sx={{ mt: 2 }}
              >
                Refresh Page
              </Button>
              
              {process.env.NODE_ENV === 'development' && this.state.error && (
                <Box sx={{ mt: 4, textAlign: 'left' }}>
                  <Typography variant="h6" color="error" gutterBottom>
                    Error Details (Development Only):
                  </Typography>
                  <Paper 
                    sx={{ 
                      p: 2, 
                      bgcolor: 'grey.100', 
                      overflowX: 'auto',
                      fontFamily: 'monospace',
                      fontSize: '0.875rem',
                      borderRadius: 1
                    }}
                  >
                    <Box component="pre" sx={{ m: 0 }}>
                      {this.state.error.toString()}
                    </Box>
                  </Paper>
                </Box>
              )}
            </Paper>
          </Box>
        </Container>
      );
    }

    // If there's no error, render the children components normally
    return this.props.children;
  }
}

export default ErrorBoundary;
