import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Paper,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  ListItemSecondaryAction,
  Avatar,
  IconButton,
  Button,
  Divider,
  Tabs,
  Tab,
  Tooltip,
  Chip,
  Badge,
  CircularProgress,
  Alert
} from '@mui/material';
import {
  Notifications as NotificationsIcon,
  Event as EventIcon,
  Work as WorkIcon,
  AssignmentLate as ReminderIcon,
  CheckCircle as CheckCircleIcon,
  Delete as DeleteIcon,
  DeleteSweep as ClearAllIcon,
  ArrowForward as ArrowForwardIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';
import { Link as RouterLink } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { format } from 'date-fns';
import { fetchJobs } from '../../slices/jobSlice';

const Notifications = () => {
  const dispatch = useDispatch();
  const [tabValue, setTabValue] = useState(0);
  const [loading, setLoading] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [error, setError] = useState(null);
  const { jobs, status } = useSelector(state => state.jobs);

  // Fetch jobs if not already loaded
  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchJobs());
    }
  }, [status, dispatch]);

  // Generate notifications based on jobs data
  useEffect(() => {
    setLoading(true);
    setError(null);

    // Short delay to ensure smooth UI transitions
    const timer = setTimeout(() => {
      try {
        // Generate notifications based on jobs
        if (jobs && jobs.length > 0) {
          const jobNotifications = [];

          // Interview notifications
          const interviewJobs = jobs.filter(job =>
            job.status === 'INTERVIEW_SCHEDULED' ||
            (job.interviews && job.interviews.length > 0)
          );

          interviewJobs.forEach(job => {
            if (job.interviews && job.interviews.length > 0) {
              job.interviews.forEach(interview => {
                const interviewDate = new Date(interview.date);
                jobNotifications.push({
                  id: `interview-${job.id}-${interview.id}`,
                  type: 'INTERVIEW',
                  title: `Upcoming interview at ${job.companyName}`,
                  message: `You have an interview for ${job.jobTitle} on ${format(interviewDate, 'MMM dd, yyyy')} at ${format(interviewDate, 'h:mm a')}`,
                  date: interviewDate,
                  read: false,
                  jobId: job.id
                });
              });
            } else if (job.status === 'INTERVIEW_SCHEDULED') {
              // If no specific interview data but status is scheduled
              jobNotifications.push({
                id: `interview-status-${job.id}`,
                type: 'INTERVIEW',
                title: `Interview scheduled at ${job.companyName}`,
                message: `Your application status for ${job.jobTitle} has been updated to Interview Scheduled.`,
                date: new Date(),
                read: false,
                jobId: job.id
              });
            }
          });

          // Follow-up reminders
          const followUpJobs = jobs.filter(job => job.followUpDate);
          followUpJobs.forEach(job => {
            const followUpDate = new Date(job.followUpDate);
            const now = new Date();
            const dayDiff = Math.ceil((followUpDate - now) / (1000 * 60 * 60 * 24));

            // Add notifications for follow-ups today or tomorrow
            if (dayDiff >= 0 && dayDiff <= 1) {
              jobNotifications.push({
                id: `followup-${job.id}`,
                type: 'REMINDER',
                title: `Follow up with ${job.companyName}`,
                message: `It's time to follow up on your ${job.jobTitle} application${dayDiff === 0 ? ' today' : ' tomorrow'}.`,
                date: followUpDate,
                read: false,
                jobId: job.id
              });
            }
            // Add notifications for overdue follow-ups
            else if (dayDiff < 0 && dayDiff > -7) { // within the last week
              jobNotifications.push({
                id: `followup-overdue-${job.id}`,
                type: 'REMINDER',
                title: `Overdue: Follow up with ${job.companyName}`,
                message: `Your follow-up for ${job.jobTitle} was due ${Math.abs(dayDiff)} day${Math.abs(dayDiff) > 1 ? 's' : ''} ago.`,
                date: followUpDate,
                read: false,
                jobId: job.id
              });
            }
          });

          // Application status change notifications
          const recentStatusChanges = jobs.filter(job => {
            return job.status === 'OFFER_RECEIVED' || job.status === 'REJECTED';
          }).slice(0, 3); // Limit to most recent 3 status changes

          recentStatusChanges.forEach(job => {
            jobNotifications.push({
              id: `status-${job.id}`,
              type: 'STATUS',
              title: `Status update: ${job.companyName}`,
              message: `Your application status for ${job.jobTitle} has been updated to ${job.status.replace('_', ' ')}.`,
              date: new Date(), // Would be the date of the status change in real app
              read: false,
              jobId: job.id
            });
          });

          // Sort notifications by date (newest first)
          jobNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));

          setNotifications(jobNotifications);
        }
      } catch (err) {
        setError('Failed to load notifications. Please try again.');
      } finally {
        setLoading(false);
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [jobs]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const markAsRead = (id) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const deleteNotification = (id) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const refreshNotifications = () => {
    dispatch(fetchJobs());
  };

  const getFilteredNotifications = () => {
    if (tabValue === 0) return notifications;
    if (tabValue === 1) return notifications.filter(n => n.type === 'INTERVIEW');
    if (tabValue === 2) return notifications.filter(n => n.type === 'REMINDER');
    if (tabValue === 3) return notifications.filter(n => n.type === 'STATUS');
    return notifications;
  };

  // Count unread notifications
  const unreadCount = notifications.filter(n => !n.read).length;

  // Get icon by notification type
  const getNotificationIcon = (type) => {
    switch (type) {
      case 'INTERVIEW':
        return <EventIcon />;
      case 'REMINDER':
        return <ReminderIcon />;
      case 'STATUS':
        return <WorkIcon />;
      default:
        return <NotificationsIcon />;
    }
  };

  // Get avatar color by notification type
  const getAvatarColor = (type) => {
    switch (type) {
      case 'INTERVIEW':
        return 'warning.light';
      case 'REMINDER':
        return 'info.light';
      case 'STATUS':
        return 'success.light';
      default:
        return 'primary.light';
    }
  };

  // Format relative time
  const formatRelativeTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now - date;
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

    if (diffInDays === 0) {
      const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
      if (diffInHours === 0) {
        const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
        return `${diffInMinutes} minute${diffInMinutes === 1 ? '' : 's'} ago`;
      }
      return `${diffInHours} hour${diffInHours === 1 ? '' : 's'} ago`;
    } else if (diffInDays === 1) {
      return 'Yesterday';
    } else if (diffInDays < 7) {
      return `${diffInDays} day${diffInDays === 1 ? '' : 's'} ago`;
    } else {
      return format(date, 'MMM dd, yyyy');
    }
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" component="h1" fontWeight="bold">
          Notifications
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          Stay updated on your job applications
        </Typography>
      </Box>

      <Paper elevation={2}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="notification tabs"
            sx={{ flexGrow: 1 }}
          >
            <Tab 
              label={
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  All
                  {unreadCount > 0 && (
                    <Badge 
                      badgeContent={unreadCount} 
                      color="error" 
                      sx={{ ml: 1 }}
                    />
                  )}
                </Box>
              } 
            />
            <Tab 
              label="Interviews" 
              icon={<EventIcon fontSize="small" />} 
              iconPosition="start" 
            />
            <Tab 
              label="Reminders" 
              icon={<ReminderIcon fontSize="small" />} 
              iconPosition="start" 
            />
            <Tab 
              label="Status Updates" 
              icon={<WorkIcon fontSize="small" />} 
              iconPosition="start" 
            />
          </Tabs>

          <Box sx={{ display: 'flex', px: 2 }}>
            <Tooltip title="Refresh notifications">
              <IconButton onClick={refreshNotifications}>
                <RefreshIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Mark all as read">
              <IconButton onClick={markAllAsRead} disabled={unreadCount === 0}>
                <CheckCircleIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Clear all notifications">
              <IconButton onClick={clearAllNotifications} disabled={notifications.length === 0}>
                <ClearAllIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        {error && (
          <Alert severity="error" sx={{ m: 2 }}>
            {error}
          </Alert>
        )}

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
            <CircularProgress />
          </Box>
        ) : getFilteredNotifications().length > 0 ? (
          <List>
            {getFilteredNotifications().map((notification, index) => (
              <React.Fragment key={notification.id}>
                <ListItem
                  alignItems="flex-start"
                  sx={{
                    bgcolor: notification.read ? 'transparent' : 'action.hover',
                    py: 2
                  }}
                >
                  <ListItemAvatar>
                    <Avatar sx={{ bgcolor: getAvatarColor(notification.type) }}>
                      {getNotificationIcon(notification.type)}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: notification.read ? 'regular' : 'bold' }}>
                          {notification.title}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {formatRelativeTime(notification.date)}
                        </Typography>
                      </Box>
                    }
                    secondary={
                      <Box sx={{ mt: 0.5 }}>
                        <Typography variant="body2" color="text.primary" paragraph sx={{ mb: 1 }}>
                          {notification.message}
                        </Typography>
                        <Button
                          variant="outlined"
                          size="small"
                          component={RouterLink}
                          to={`/jobs/${notification.jobId}`}
                          endIcon={<ArrowForwardIcon />}
                          onClick={() => markAsRead(notification.id)}
                        >
                          View Job
                        </Button>
                      </Box>
                    }
                    secondaryTypographyProps={{ component: 'div' }}
                  />
                  <ListItemSecondaryAction>
                    <Tooltip title="Delete notification">
                      <IconButton edge="end" onClick={() => deleteNotification(notification.id)}>
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>
                  </ListItemSecondaryAction>
                </ListItem>
                {index < getFilteredNotifications().length - 1 && <Divider component="li" />}
              </React.Fragment>
            ))}
          </List>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 6 }}>
            <NotificationsIcon sx={{ fontSize: 60, color: 'text.disabled', mb: 2 }} />
            <Typography variant="h6" color="text.secondary">
              No notifications
            </Typography>
            <Typography variant="body2" color="text.disabled" sx={{ mt: 1 }}>
              {tabValue === 0
                ? 'You don\'t have any notifications right now.'
                : tabValue === 1
                ? 'You don\'t have any interview notifications.'
                : tabValue === 2
                ? 'You don\'t have any reminders.'
                : 'You don\'t have any status updates.'}
            </Typography>
          </Box>
        )}
      </Paper>
    </Container>
  );
};

export default Notifications;