import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import {
  Avatar,
  Button,
  TextField,
  Link,
  Grid,
  Box,
  Typography,
  Container,
  Alert,
  Card,
  CardContent,
  InputAdornment,
  IconButton,
  CircularProgress,
  Paper
} from '@mui/material';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { login } from '../../slices/authSlice';

const Login = () => {
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { error } = useSelector(state => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: {
      username: '',
      password: ''
    },
    validationSchema: Yup.object({
      username: Yup.string().required('Username is required'),
      password: Yup.string().required('Password is required')
    }),
    onSubmit: (values) => {
      setLoading(true);
      dispatch(login(values))
        .unwrap()
        .then(() => {
          navigate('/');
        })
        .catch(() => {
          setLoading(false);
        });
    }
  });

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Container component="main" maxWidth="xs">
      <Card 
        elevation={3}
        sx={{
          mt: 8,
          mb: 4,
          borderRadius: 2,
          overflow: 'visible',
          position: 'relative'
        }}
      >
        <Avatar 
          sx={{ 
            bgcolor: 'primary.main', 
            width: 56, 
            height: 56, 
            position: 'absolute', 
            top: -28, 
            left: 'calc(50% - 28px)',
            boxShadow: 2
          }}
        >
          <LockOutlinedIcon />
        </Avatar>
        
        <CardContent sx={{ pt: 5, pb: 4, px: 3, mt: 2 }}>
          <Typography component="h1" variant="h5" align="center" gutterBottom>
            Sign In
          </Typography>
          <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
            Sign in to track your job applications
          </Typography>
          
          {error && 
            <Alert 
              severity="error" 
              sx={{ 
                width: '100%', 
                mb: 3,
                borderRadius: 1
              }}
            >
              {error}
            </Alert>
          }
          
          <Box component="form" onSubmit={formik.handleSubmit}>
            <TextField
              margin="normal"
              required
              fullWidth
              id="username"
              label="Username"
              name="username"
              autoComplete="username"
              autoFocus
              value={formik.values.username}
              onChange={formik.handleChange}
              error={formik.touched.username && Boolean(formik.errors.username)}
              helperText={formik.touched.username && formik.errors.username}
              InputProps={{
                sx: { borderRadius: 1 }
              }}
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type={showPassword ? 'text' : 'password'}
              id="password"
              autoComplete="current-password"
              value={formik.values.password}
              onChange={formik.handleChange}
              error={formik.touched.password && Boolean(formik.errors.password)}
              helperText={formik.touched.password && formik.errors.password}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
                sx: { borderRadius: 1 }
              }}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2, py: 1.2, borderRadius: 1 }}
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} color="inherit" /> : 'Sign In'}
            </Button>
            <Grid container justifyContent="flex-end">
              <Grid item>
                <Link component={RouterLink} to="/register" variant="body2" underline="hover">
                  {"Don't have an account? Sign Up"}
                </Link>
              </Grid>
            </Grid>
          </Box>
        </CardContent>
      </Card>
      
      <Paper 
        elevation={1} 
        sx={{ 
          p: 3, 
          borderRadius: 2, 
          bgcolor: 'background.paper',
          mb: 4
        }}
      >
        <Typography variant="body2" color="text.secondary" align="center" gutterBottom>
          Demo Credentials
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
          <Typography variant="body2" color="text.primary">Username: demo</Typography>
          <Typography variant="body2" color="text.primary">Password: password123</Typography>
        </Box>
      </Paper>
    </Container>
  );
};

export default Login;