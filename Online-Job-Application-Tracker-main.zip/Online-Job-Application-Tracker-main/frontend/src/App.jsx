import React, { useEffect, Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { Box, Container, CssBaseline } from '@mui/material';
import { jwtDecode } from 'jwt-decode';
import { logout } from './slices/authSlice';
import authService from './services/authService';
import PageLoader from './components/common/PageLoader';

// Lazy load components for better performance
const Login = lazy(() => import('./components/auth/Login'));
const Register = lazy(() => import('./components/auth/Register'));
const Dashboard = lazy(() => import('./components/dashboard/Dashboard'));
const JobsList = lazy(() => import('./components/jobs/JobsList'));
const JobDetail = lazy(() => import('./components/jobs/JobDetail'));
const AddJob = lazy(() => import('./components/jobs/AddJob'));
const EditJob = lazy(() => import('./components/jobs/EditJob'));
const Profile = lazy(() => import('./components/user/Profile'));
const Settings = lazy(() => import('./components/user/Settings'));
const Notifications = lazy(() => import('./components/notifications/Notifications'));
const Header = lazy(() => import('./components/layout/Header'));
const NotFound = lazy(() => import('./components/NotFound'));
const Footer = lazy(() => import('./components/layout/Footer'));

const App = () => {
  const { isLoggedIn } = useSelector(state => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    const user = authService.getCurrentUser();
    if (user) {
      // Check token expiration by decoding the JWT
      try {
        const decoded = jwtDecode(user.token);
        if (decoded.exp * 1000 < Date.now()) {
          // Token has expired
          dispatch(logout());
        }
      } catch (error) {
        // If token is invalid, log out
        console.error('Invalid token:', error);
        dispatch(logout());
      }
    }
  }, [dispatch]);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <CssBaseline />
      <Suspense fallback={<PageLoader message="Loading application..." />}>
        <Header />
        <Container 
          component="main" 
          sx={{ 
            flexGrow: 1, 
            p: { xs: 2, sm: 3 }, 
            mt: 8, 
            mb: 4,
            display: 'flex',
            flexDirection: 'column'
          }}
        >
          <Routes>
            <Route path="/" element={isLoggedIn ? <Dashboard /> : <Navigate to="/login" />} />
            <Route path="/login" element={!isLoggedIn ? <Login /> : <Navigate to="/" />} />
            <Route path="/register" element={!isLoggedIn ? <Register /> : <Navigate to="/" />} />
            <Route path="/jobs" element={isLoggedIn ? <JobsList /> : <Navigate to="/login" />} />
            <Route path="/jobs/:id" element={isLoggedIn ? <JobDetail /> : <Navigate to="/login" />} />
            <Route path="/jobs/add" element={isLoggedIn ? <AddJob /> : <Navigate to="/login" />} />
            <Route path="/jobs/edit/:id" element={isLoggedIn ? <EditJob /> : <Navigate to="/login" />} />
            <Route path="/profile" element={isLoggedIn ? <Profile /> : <Navigate to="/login" />} />
            <Route path="/settings" element={isLoggedIn ? <Settings /> : <Navigate to="/login" />} />
            <Route path="/notifications" element={isLoggedIn ? <Notifications /> : <Navigate to="/login" />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Container>
        <Footer />
      </Suspense>
    </Box>
  );
};

export default App;